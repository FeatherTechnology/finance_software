
class TestClass {
    checking(value) {
        console.log(value);
    }
}

export { TestClass };