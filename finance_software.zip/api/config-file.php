<?php
$HOSTPATH = "https://" . $_SERVER['HTTP_HOST'] . "/finance_software/";

define('HOSTPATH', $HOSTPATH);
